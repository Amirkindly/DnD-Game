// ===== ابزارها =====
const $=s=>document.querySelector(s),R=n=>Math.floor(Math.random()*n),d=s=>1+R(s),roll=(n,s)=>{let t=0;for(let i=0;i<n;i++)t+=d(s);return t},mod=v=>Math.floor((v-10)/2),wait=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sg=n=>(n>=0?'+':'')+n,fmt=n=>Math.round(n).toLocaleString('en');
const KEY='adv_save_v1';let DB;try{DB=JSON.parse(localStorage.getItem(KEY))}catch(e){}
DB=DB||{chars:[],set:{}};DB.set=Object.assign({anim:1,snd:1,vib:1,pin:'1234'},DB.set||{});
const save=()=>{try{const t=new Date().toDateString();if(DB.bakd!==t){const prev=localStorage.getItem(KEY);if(prev)localStorage.setItem(KEY+'_bak',prev);DB.bakd=t}localStorage.setItem(KEY,JSON.stringify(DB))}catch(e){alert('حافظه پر است')}};

// ===== ویژگی‌ها، نژاد، کلاس =====
const STATS=[['str','قدرت بدنی'],['spd','سرعت'],['con','استقامت'],['mag','جادو'],['pow','نیرو'],['aura','هاله']];
const STN=Object.fromEntries(STATS);
const STD={str:'آسیب و دقت سلاح‌های سنگین',spd:'زره، ابتکار عمل، فرار و تیراندازی',con:'جان بیشتر',mag:'قدرت جادو و درمان',pow:'آسیب اضافه‌ی مهارت‌های ویژه',aura:'فقط شوالیه: قدرت منبع هاله و زره'};
const RACES={human:{n:'انسان',b:{str:1,spd:1,con:1,mag:1,pow:1}},elf:{n:'الف',b:{spd:2,mag:1}},dwarf:{n:'کوتوله',b:{con:2,str:1}},orc:{n:'ارک',b:{str:2,pow:1,mag:-1}}};
const CLS={
fighter:{n:'جنگجو',e:'⚔️',hp:12,hpl:7,key:'pow',res:'انرژی',col:'#e08a3a',base:{str:14,spd:11,con:13,mag:8,pow:12,aura:0},kit:['sword','leather','wshield','hp1','hp1'],d:'قدرت بدنی و استقامت بالا؛ تانک و ضربه‌زن.',
 ab:[{n:'ضربه‌ی قدرتمند',lv:1,c:3,k:'atk',x:[1,8]},{n:'خشم نبرد',lv:3,c:5,k:'atk',x:[2,8]},{n:'ضربه‌ی نهایی',lv:5,c:8,k:'atk',x:[4,10]},{n:'ضربه‌ی زلزله',lv:8,c:10,k:'atk',x:[6,10]},{n:'ضربه‌ی افسانه‌ای',lv:14,c:14,k:'atk',x:[9,12]},{n:'خشم تایتان',lv:22,c:20,k:'atk',x:[14,12]}]},
rogue:{n:'سارق',e:'🗡️',hp:8,hpl:5,key:'pow',res:'انرژی',col:'#c9b037',base:{str:9,spd:15,con:11,mag:10,pow:12,aura:0},kit:['dagger','leather','hp1','hp1'],d:'سرعت بالا و ضربه‌های مرگبار؛ جان کم.',
 ab:[{n:'ضربه‌ی پنهان',lv:1,c:3,k:'atk',x:[2,6]},{n:'تیغ مسموم',lv:3,c:5,k:'atk',x:[3,6]},{n:'مرگ سایه',lv:5,c:8,k:'atk',x:[5,6]},{n:'رقص تیغ',lv:8,c:10,k:'atk',x:[8,6]},{n:'قتل بی‌صدا',lv:14,c:14,k:'atk',x:[12,8]},{n:'طوفان سایه‌ها',lv:22,c:20,k:'atk',x:[18,8]}]},
wizard:{n:'جادوگر',e:'🔮',hp:6,hpl:4,key:'mag',res:'مانا',col:'#4a90d9',base:{str:8,spd:11,con:10,mag:15,pow:11,aura:0},kit:['staff','robe','hp1','mp1'],d:'جادوی ویرانگر؛ بدن ضعیف.',
 ab:[{n:'پرتاب جادو',lv:1,c:2,k:'spell',x:[2,6]},{n:'گلوله‌ی آتش',lv:3,c:5,k:'spell',x:[4,6]},{n:'صاعقه',lv:5,c:8,k:'spell',x:[7,6]},{n:'توفان یخ',lv:8,c:10,k:'spell',x:[10,6]},{n:'شهاب‌سنگ',lv:14,c:15,k:'spell',x:[14,8]},{n:'فروپاشی ستاره',lv:22,c:22,k:'spell',x:[20,8]}]},
cleric:{n:'کشیش',e:'✝️',hp:9,hpl:6,key:'mag',res:'مانا',col:'#5cd9c0',base:{str:11,spd:9,con:12,mag:14,pow:10,aura:0},kit:['mace','leather','wshield','hp1','mp1'],d:'درمان و نور مقدس.',
 ab:[{n:'نور مقدس',lv:1,c:2,k:'spell',x:[2,6]},{n:'درمان',lv:1,c:3,k:'heal',x:[2,8]},{n:'درمان بزرگ',lv:3,c:6,k:'heal',x:[4,8]},{n:'عذاب الهی',lv:5,c:8,k:'spell',x:[6,6]},{n:'درمان الهی',lv:8,c:10,k:'heal',x:[8,8]},{n:'خشم آسمان',lv:12,c:12,k:'spell',x:[10,8]},{n:'رستاخیز',lv:16,c:16,k:'heal',x:[14,8]}]},
knight:{n:'شوالیه',e:'🛡️',hp:11,hpl:7,key:'aura',res:'هاله',col:'#d9d94a',base:{str:13,spd:9,con:13,mag:9,pow:11,aura:13},kit:['sword','chain','ishield','hp1'],d:'هاله‌ی محافظ؛ زره بالا و ضربه‌ی مقدس. هاله زره هم‌تیمی‌ها رو هم بالا می‌بره.',
 ab:[{n:'ضربه‌ی مقدس',lv:1,c:3,k:'atk',x:[2,6]},{n:'بازیابی هاله',lv:3,c:4,k:'heal',x:[2,8]},{n:'ضربه‌ی نور',lv:5,c:8,k:'atk',x:[4,8]},{n:'هاله‌ی شفابخش',lv:8,c:8,k:'heal',x:[6,8]},{n:'ضربه‌ی خورشید',lv:10,c:10,k:'atk',x:[8,8]},{n:'نور مطلق',lv:16,c:16,k:'atk',x:[12,10]}]}
};
const RANKS=['F','E','D','C','B','A','S','SS','SSS'],RANKREP=[0,30,90,200,400,700,1100,1800,3000];
const thr=l=>Math.round(100*Math.pow(l,1.9));
const RAR=['معمولی','غیرمعمول','کمیاب','بسیار کمیاب','افسانه‌ای','اسطوره‌ای'],RCOL=['#bbb','#5cb85c','#4a90d9','#a463d9','#e8b84a','#ff5a5a'];
const SLOTS=[['weapon','سلاح'],['armor','زره'],['shield','سپر'],['helm','کلاه'],['boots','چکمه'],['ring','حلقه'],['amulet','گردنبند']];
const rng=(x)=>`${x[0]} تا ${x[0]*x[1]}`;

// ===== تجهیزات (ساخته‌شده خودکار: ۱۰ مرحله برای هر نوع) =====
const I=(n,e,t,r,p,o={})=>({n,e,t,r,p,...o});
const ITEMS={
dagger:I('خنجر','🗡️','weapon',0,10,{st:'spd',dm:[1,4,0]}),sword:I('شمشیر کوتاه','⚔️','weapon',0,20,{st:'str',dm:[1,6,0]}),mace:I('گرز','🔨','weapon',0,25,{st:'str',dm:[1,6,1]}),staff:I('عصای چوبی','🪄','weapon',0,20,{st:'mag',dm:[1,6,0]}),
leather:I('زره چرمی','🦺','armor',0,15,{ac:1}),robe:I('ردای جادوگر','🧥','armor',1,60,{ac:1,b:{mag:1}}),chain:I('زره زنجیری','⛓️','armor',1,100,{ac:3}),
wshield:I('سپر چوبی','🪵','shield',0,10,{ac:1}),ishield:I('سپر آهنی','🔰','shield',1,60,{ac:2}),
longsword:I('شمشیر بلند','⚔️','weapon',1,60,{st:'str',dm:[1,8,1]}),axe:I('تبر جنگی','🪓','weapon',1,80,{st:'str',dm:[1,10,1]}),bow:I('کمان شکاری','🏹','weapon',1,70,{st:'spd',dm:[1,8,1]}),
plate:I('زره صفحه‌ای','🛡️','armor',2,400,{ac:5}),ihelm:I('کلاه آهنی','⛑️','helm',0,25,{ac:1}),mhelm:I('کلاه جادویی','🎩','helm',2,300,{b:{mag:2}}),
lboots:I('چکمه‌ی چرمی','🥾','boots',1,80,{b:{spd:1}}),wboots:I('چکمه‌ی باد','💨','boots',3,600,{b:{spd:2}}),strring:I('حلقه‌ی قدرت','💍','ring',1,120,{b:{str:1}}),powring:I('حلقه‌ی نیرو','💎','ring',2,350,{b:{pow:2}}),
lifeamu:I('گردنبند جان','📿','amulet',2,350,{b:{con:2}}),auraamu:I('گردنبند هاله','🧿','amulet',3,600,{b:{aura:2}}),
cstaff:I('عصای کریستالی','🔮','weapon',2,250,{st:'mag',dm:[1,8,2]}),flame:I('شمشیر شعله','🔥','weapon',3,700,{st:'str',dm:[2,6,2]}),shadow:I('تیغ سایه','🌑','weapon',3,700,{st:'spd',dm:[2,6,2]}),
sky:I('عصای آسمانی','✨','weapon',4,1800,{st:'mag',dm:[2,8,3]}),excal:I('شمشیر افسانه‌ای','🏆','weapon',4,4000,{st:'str',dm:[3,8,4]}),dragon:I('زره اژدها','🐲','armor',4,3000,{ac:7,b:{con:2}})};
const TM=['کهنه','آهنی','فولادی','نقره‌ای','میترلی','گوهری','اژدهایی','آسمانی','الهی','کیهانی'],TMC=['چوبی','بلوطی','کریستالی','یاقوتی','ستاره‌ای','ارواح','اژدهایی','آسمانی','الهی','کیهانی'];
const rt=t=>Math.min(5,Math.floor((t+1)/2)),pr=(b,t)=>Math.round(b*Math.pow(2.1,t));
[['شمشیر','⚔️','str',8,'sw'],['تبر','🪓','str',10,'ax'],['گرز','🔨','str',8,'mc'],['نیزه','🔱','str',8,'sp'],['خنجر','🗡️','spd',6,'dg'],['کمان','🏹','spd',8,'bw'],['عصا','🪄','mag',6,'st'],['گوی جادو','🔮','mag',8,'or']].forEach(([n,e,st,s,k])=>{for(let t=0;t<10;t++)ITEMS[`w_${k}_${t}`]=I(`${n} ${st==='mag'?TMC[t]:TM[t]}`,e,'weapon',rt(t),pr(14,t),{st,dm:[1+Math.floor(t/2),s,Math.floor(t/2)],tr:t})});
for(let t=0;t<10;t++){
 ITEMS['a_rb_'+t]=I(`ردای ${TMC[t]}`,'🧥','armor',rt(t),pr(12,t),{ac:1+Math.floor(t/2),b:{mag:1+Math.floor(t/2)},tr:t});
 ITEMS['a_lt_'+t]=I(`زره چرمی ${TM[t]}`,'🦺','armor',rt(t),pr(12,t),{ac:2+Math.floor(t*.8),tr:t});
 ITEMS['a_hv_'+t]=I(`زره سنگین ${TM[t]}`,'🛡️','armor',rt(t),pr(14,t),{ac:3+t,tr:t});
 ITEMS['s_'+t]=I(`سپر ${TM[t]}`,'🔰','shield',rt(t),pr(10,t),{ac:1+Math.floor(t*.7),tr:t});
 ITEMS['h_'+t]=I(`کلاه ${TM[t]}`,'⛑️','helm',rt(t),pr(10,t),{ac:1+Math.floor(t/2),tr:t});
 ITEMS['b_'+t]=I(`چکمه ${TM[t]}`,'🥾','boots',rt(t),pr(20,t),{b:{spd:1+Math.floor(t*.6)},tr:t});
 STATS.forEach(([k,n])=>{ITEMS[`r_${k}_${t}`]=I(`حلقه‌ی ${n} ${TM[t]}`,'💍','ring',rt(t),pr(40,t),{b:{[k]:1+Math.floor(t*.6)},tr:t});ITEMS[`m_${k}_${t}`]=I(`گردنبند ${n} ${TM[t]}`,'📿','amulet',rt(t),pr(50,t),{b:{[k]:1+Math.floor(t*.8)},tr:t})});
}
const PH=['hp1','hp2','hp3','hp4','hp5','hp6'],PM=['mp1','mp2','mp3'];
[[20,25],[50,80],[120,250],[300,600],[800,2000],[2000,6000]].forEach(([h,p],i)=>{ITEMS['hp'+(i+1)]=I(['معجون جان کوچک','معجون جان متوسط','معجون جان بزرگ','معجون جان عالی','معجون جان افسانه‌ای','اکسیر زندگی'][i],'🧪','potion',Math.min(5,i),p,{heal:h,tr:i})});
[[15,40],[40,150],[100,500]].forEach(([m,p],i)=>{ITEMS['mp'+(i+1)]=I(['معجون منبع','معجون منبع بزرگ','اکسیر منبع'][i],'💧','potion',i,p,{mpr:m,tr:i})});
const mk=(id,u=0)=>({id,u});
function iv(o){const b=ITEMS[o.id],u=o.u||0,r={...b,u},t=b.tr!==undefined?b.tr:b.r*2;
 if(b.dm)r.dm=[b.dm[0],b.dm[1],b.dm[2]+u*(1+Math.floor(t/2))];
 if(b.ac!=null)r.ac=b.ac+Math.ceil(u/2);
 if(b.b){r.b={};for(const k in b.b)r.b[k]=b.b[k]+Math.floor(u/3)}
 return r}
function desc(o){const v=iv(o),s=[];
 if(v.dm)s.push(`⚔️ آسیب ${v.dm[0]+v.dm[2]} تا ${v.dm[0]*v.dm[1]+v.dm[2]} (با ${STN[v.st]})`);
 if(v.ac!=null)s.push(`🛡️ ${v.ac}+ زره`);
 if(v.b)for(const k in v.b)s.push(`✨ ${v.b[k]}+ ${STN[k]}`);
 if(v.heal)s.push(`❤️ ${v.heal} جان برمی‌گردونه`);if(v.mpr)s.push(`💧 ${v.mpr} منبع برمی‌گردونه`);return s.join(' · ')}
function score(o){const v=iv(o);let s=0;if(v.dm)s+=(v.dm[0]*(v.dm[1]+1)/2+v.dm[2])*1.5;if(v.ac)s+=v.ac*2;if(v.b)for(const k in v.b)s+=v.b[k]*1.5;return s}
const UPC=[100,100,95,90,80,70,60,50,40,30,25,20,15,10,5],UMAX=15;
const upCost=o=>{const u=o.u||0;return{g:Math.round(ITEMS[o.id].p*.22*Math.pow(u+1,1.5))+25,s:1+Math.floor(u/3),c:UPC[u]}};
const sellP=o=>Math.floor(ITEMS[o.id].p*(1+(o.u||0)*.5)/2);

// ===== هیولاها =====
const ROL={n:[1,0,0],b:[1.5,-2,0],f:[.7,1,2],t:[1.2,3,0]};
function MON(n,ty,cl,lv,ro='n',boss=0){const r=ROL[ro],bm=boss?2.8:1;
 return{n,ty,cl,lv,ro,boss,hp:Math.round((6+lv*10)*r[0]*bm),ac:10+Math.floor(lv*.55)+r[1]+(boss?2:0),atk:2+Math.round(lv*.95)+r[2]+(boss?2:0),d:[1+Math.floor(lv/3)+(boss?1:0),8,1+Math.floor(lv/2)],xp:Math.round((10+lv*14)*(boss?5:1)),g:Math.round((4+lv*6)*(boss?8:1))}}
const AR=(n,e,lv,rank,col,list,b)=>({n,e,lv,rank,col,mon:list.map(([n,ty,cl,ro,dl=0])=>MON(n,ty,cl,lv+dl,ro)),boss:MON(b[0],b[1],b[2],lv+1,'n',1)});
const AREAS={
forest:AR('جنگل تاریک','🌲',1,0,'#1f3a1f',[['گرگ','wolf',['#8a8a8a','#555','#ffd34d'],'f'],['گابلین','goblin',['#6bbf59','#3b7a2c','#ffd34d']],['عنکبوت غول‌پیکر','spider',['#3a2f45','#241a2e','#ff4d4d'],'f',1],['لجن جنگلی','slime',['#7fd36b','#3d8a35','#ffffff'],'b']],['شاه گابلین','goblin',['#4d9a3a','#2c5e22','#ffcf33']]),
cave:AR('غار تاریک','🕳️',2,0,'#333a45',[['خفاش غار','bat',['#5b4a6e','#3a2d4a','#ff5577'],'f'],['اسکلت','skull',['#e8dfc4','#a89f84','#66ccff']],['اوگر','ogre',['#8a9a5a','#5a6a3a','#e8dfc4'],'b',1],['گولم سنگی','golem',['#8a8f99','#555a66','#ff9a3d'],'t',1]],['اژدهای کوچک','dragon',['#c0392b','#7a2018','#ffd34d']]),
swamp:AR('باتلاق مه‌آلود','🐊',4,1,'#2b3a2a',[['زامبی','zombie',['#7fa36a','#4a6a3a','#d8ff6a']],['مار سمی','snake',['#4c9a5a','#2c5e36','#ffd34d'],'f'],['لجن سمی','slime',['#a06be0','#5a2f8a','#ffffff'],'b'],['هیدرا','hydra',['#3f8a6a','#285a44','#ff6b3d'],'n',1]],['ملکه‌ی باتلاق','mage',['#2f6a4a','#173a28','#7cff6a']]),
desert:AR('صحرای سوزان','🏜️',5,2,'#5a4521',[['عقرب غول‌پیکر','scorp',['#c9a24a','#8a6a22','#ff5533'],'f'],['مومیا','mummy',['#d8c9a0','#9a8a60','#66ccff']],['گولم شنی','golem',['#d1a95a','#8a6a2a','#ff5533'],'t'],['لاشخور','bird',['#8a7a5a','#4a3a2a','#ff9a3d'],'f',1]],['فرعون نفرین‌شده','mummy',['#e0c050','#8a6a22','#44ffcc']]),
mountain:AR('کوهستان برفی','🏔️',7,3,'#3a4a5a',[['گرگ برفی','wolf',['#e8f0f8','#9ab0c8','#66ccff'],'f'],['ترول','ogre',['#6a8a7a','#3a5a4a','#e8dfc4'],'b'],['غول یخی','crystal',['#7fd0ff','#3a7aa8','#ffffff'],'t'],['هارپی','bird',['#c8d4e0','#7a8aa0','#ff6b6b'],'f',1]],['اژدهای یخی','dragon',['#4aa3d8','#1f5a88','#e8f8ff']]),
castle:AR('قلعه‌ی ملعون','🏰',9,4,'#3a2540',[['شوالیه‌ی تاریک','knight',['#7f8a99','#454c58','#cc2f2f'],'t'],['شبح','ghost',['#aab6e8','#6a74a8','#66ccff'],'f'],['جادوگر سیاه','mage',['#4a2f7a','#2a1a4a','#7cff6a']],['اسکلت سلطنتی','skull',['#c9b887','#7a6a44','#ff4466'],'n',1]],['پادشاه لیچ','skull',['#9ad0e8','#3a6a88','#66ffee']]),
volcano:AR('دره‌ی آتشفشان','🌋',12,5,'#5a2418',[['عنصر آتش','flame',['#ff6a1a','#a82a0a','#ffd34d'],'f'],['شیطان کوچک','demon',['#9b2d30','#5a1214','#e8b84a']],['گولم گدازه','golem',['#5a3a30','#2a1a16','#ff7a1a'],'t'],['مار آتشین','snake',['#d9541f','#7a2210','#ffd34d'],'f',1]],['لرد آتش','demon',['#c0392b','#6a1410','#ffd34d']]),
abyss:AR('ورطه‌ی تاریکی','🌑',16,6,'#1c1830',[['شبح ورطه','ghost',['#6a5aa8','#2a2250','#c06bff'],'f'],['عنکبوت تهی','spider',['#2a1f3a','#120a1e','#c06bff'],'f'],['شیطان سایه','demon',['#3a2a5a','#1a1030','#c06bff'],'n',1],['لجن تاریک','slime',['#3a2a5a','#1a1030','#c06bff'],'b']],['سلطان ورطه','demon',['#5a2a8a','#2a1050','#ff6bd0']]),
sky:AR('قلعه‌ی آسمانی','☁️',20,7,'#2c4a6a',[['عقاب رعد','bird',['#e8d89a','#a8883a','#66e8ff'],'f'],['نگهبان کریستالی','crystal',['#e8d0ff','#8a6ac8','#ffffff'],'t'],['فرشته‌ی سقوط‌کرده','knight',['#e8e0c0','#a89860','#ff6bd0'],'n',1],['اژدهای توفان','dragon',['#4a7ad8','#1f3a88','#ffe34d'],'n',2]],['فرمانروای آسمان','dragon',['#e8c050','#8a6a22','#ffffff']])
};
const AKEYS=Object.keys(AREAS);
const ALLM=[];AKEYS.forEach(a=>{AREAS[a].mon.forEach(m=>ALLM.push({m,a}));ALLM.push({m:AREAS[a].boss,a})});

// ===== کوئست‌ها (ساخته‌شده خودکار) =====
const QUESTS=[];
AKEYS.forEach((a,i)=>{const A=AREAS[a];
 A.mon.forEach(m=>[[5,'شکار'],[15,'قتل‌عام']].forEach(([c,w])=>QUESTS.push({id:`${a}_${m.n}_${c}`,t:'sp',sp:m.n,a,cnt:c,rank:A.rank,cat:'sp',n:`${w} ${m.n}`,d:`${c} تا ${m.n} بکش (${A.n})`,g:Math.round(c*m.g*1.2),x:Math.round(c*m.xp*.8),rep:Math.max(3,Math.round(c*m.xp/40))})));
 QUESTS.push({id:a+'_area',t:'area',a,cnt:12,rank:A.rank,cat:'area',n:'پاکسازی '+A.n,d:`۱۲ هیولا در ${A.n} بکش`,g:Math.round(12*A.mon[0].g*1.3),x:Math.round(12*A.mon[0].xp),rep:Math.max(6,Math.round(12*A.mon[0].xp/35))},
  {id:a+'_boss',t:'boss',sp:A.boss.n,a,cnt:1,rank:A.rank,cat:'boss',n:'نابودی '+A.boss.n,d:`${A.boss.n} رو شکست بده (بعد از چند بار کاوش ظاهر می‌شه)`,g:A.boss.g*2,x:A.boss.xp,rep:Math.max(10,Math.round(A.boss.xp/10))})});
[[25,0],[100,1],[300,3],[1000,5]].forEach(([c,r])=>QUESTS.push({id:'any_'+c,t:'any',cnt:c,rank:r,cat:'misc',n:`شکارچی ${c}تایی`,d:`${c} هیولا در هر جایی بکش`,g:c*18,x:c*25,rep:Math.round(c/3)}));
[[10,0],[30,1],[100,3]].forEach(([c,r])=>QUESTS.push({id:'exp_'+c,t:'exp',cnt:c,rank:r,cat:'misc',n:`کاشف ${c}تایی`,d:`${c} بار کاوش کن`,g:c*20,x:c*18,rep:Math.round(c/2)}));
[[3,0],[10,1],[25,3]].forEach(([c,r])=>QUESTS.push({id:'ev_'+c,t:'ev',cnt:c,rank:r,cat:'misc',n:`ماجراجوی ${c}رویدادی`,d:`${c} رویداد (تله، صندوق، مسافر...) رو انجام بده`,g:c*40,x:c*30,rep:c*2}));
[[1,0],[3,1],[10,3]].forEach(([c,r])=>QUESTS.push({id:'upg_'+c,t:'upg',cnt:c,rank:r,cat:'misc',n:`آهنگر ${c}ارتقایی`,d:`${c} بار ارتقای موفق انجام بده`,g:c*80,x:c*60,rep:c*4}));
[[3,2],[10,4],[25,6]].forEach(([c,r])=>QUESTS.push({id:'bosses_'+c,t:'bosses',cnt:c,rank:r,cat:'misc',n:`باس‌کش ${c}تایی`,d:`${c} باس رو شکست بده`,g:c*300,x:c*250,rep:c*15}));
const EVENTS=[
{t:'🪤 تله‌ی باستانی',d:'کف زمین پر از مکانیزم‌های زنگ‌زده است.',o:[{l:'خنثی‌سازی',s:'spd',dc:12},{l:'عبور با زور',s:'str',dc:13},{l:'دور زدن'}]},
{t:'📦 صندوق قفل‌شده',d:'صندوقی قدیمی وسط راهه.',o:[{l:'قفل‌شکنی',s:'spd',dc:13,item:1},{l:'شکستن در',s:'str',dc:14,item:1},{l:'جادوی گشایش',s:'mag',dc:13,item:1}]},
{t:'🧙 مسافر مرموز',d:'مردی با شنل ازت کمک می‌خواد.',o:[{l:'متقاعد کردن',s:'pow',dc:12},{l:'نادیده گرفتن'}]},
{t:'⛩️ محراب قدیمی',d:'محرابی که هنوز می‌درخشه.',o:[{l:'دعا کردن',s:'mag',dc:12},{l:'دست نزدن'}]},
{t:'🕳️ چاه عمیق',d:'از ته چاه صدای سکه میاد.',o:[{l:'پایین رفتن',s:'str',dc:13},{l:'طناب انداختن',s:'spd',dc:12}]},
{t:'🍄 قارچ‌های درخشان',d:'قارچ‌هایی با نور عجیب دورت رو گرفتن.',o:[{l:'جمع کردن',s:'con',dc:12},{l:'تحلیل جادویی',s:'mag',dc:13}]}];
const ACH=[
{id:'k1',n:'اولین خون',d:'اولین هیولات رو بکش',f:c=>c.kills>=1,g:50},{id:'k100',n:'شکارچی',d:'۱۰۰ هیولا',f:c=>c.kills>=100,g:500,s:2},{id:'k1000',n:'قاتل افسانه‌ای',d:'۱۰۰۰ هیولا',f:c=>c.kills>=1000,g:8000,s:10},
{id:'l10',n:'باتجربه',d:'رسیدن به لول ۱۰',f:c=>c.lvl>=10,g:800,s:3},{id:'l25',n:'قهرمان',d:'رسیدن به لول ۲۵',f:c=>c.lvl>=25,g:6000,s:8},{id:'l50',n:'اسطوره',d:'رسیدن به لول ۵۰',f:c=>c.lvl>=50,g:40000,s:25},
{id:'rB',n:'رنک B انفرادی',d:'رنک انفرادی B',f:c=>c.rank>=4,g:1500,s:3},{id:'tC',n:'تیم قدرتمند',d:'رنک تیمی C',f:c=>c.trank>=3,g:1200,s:3},{id:'rS',n:'رنک S',d:'رنک انفرادی S',f:c=>c.rank>=6,g:8000,s:10},
{id:'u5',n:'آهنگر ماهر',d:'ارتقای یه آیتم تا +5',f:c=>maxU(c)>=5,g:600,s:2},{id:'u10',n:'استاد آهنگر',d:'ارتقای یه آیتم تا +10',f:c=>maxU(c)>=10,g:5000,s:8},
{id:'b5',n:'باس‌کش',d:'۵ باس',f:c=>c.bk>=5,g:1000,s:3},{id:'b25',n:'نابودگر باس‌ها',d:'۲۵ باس',f:c=>c.bk>=25,g:10000,s:12},
{id:'t10',n:'پله‌های برج',d:'رسیدن به طبقه ۱۰ برج',f:c=>c.tower>=10,g:1500,s:4},{id:'t50',n:'فاتح برج',d:'رسیدن به طبقه ۵۰ برج',f:c=>c.tower>=50,g:20000,s:20},
{id:'q10',n:'کارمند انجمن',d:'۱۰ کوئست',f:c=>c.qd>=10,g:700,s:2},{id:'q50',n:'قهرمان انجمن',d:'۵۰ کوئست',f:c=>c.qd>=50,g:6000,s:10}];
const maxU=c=>Math.max(0,...Object.values(c.eq).map(o=>o.u||0),...c.inv.map(o=>o.u||0));
const NAMES=['آرمان','سیاوش','رستم','مهسا','آیدا','کوروش','بهرام','شیرین','داریوش','نیلوفر','آرش','ماهان','سودابه','پارسا','هیربد','یلدا','کیان','سورنا','آناهیتا','دلارام','تیرداد','رودابه','کاووس','سپیده'];
const TIER=['معمولی','کمیاب','افسانه‌ای'],TP=[100,400,1500],TCOL=['#665544','#3a6ea5','#b8862b'];
