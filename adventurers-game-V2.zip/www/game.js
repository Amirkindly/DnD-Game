// ===== صدا و تاس =====
let AU;function beep(f,t=.05,v=.07){if(!DB.set.snd)return;try{AU=AU||new(window.AudioContext||window.webkitAudioContext)();const o=AU.createOscillator(),g=AU.createGain();o.type='triangle';o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(AU.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,AU.currentTime+t);o.stop(AU.currentTime+t)}catch(e){}}
const vib=p=>{try{if(DB.set.vib&&navigator.vibrate)navigator.vibrate(p)}catch(e){}};
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2000)}
let skip=false;
function dice(sides,val,label){return new Promise(res=>{
 if(!DB.set.anim){res();return}
 const o=$('#dice'),n=$('#dnum'),die=$('#die');$('#dlab').textContent=label||'';$('#dsub').textContent='d'+sides;
 o.classList.add('show');die.classList.remove('land');die.style.animation='none';void die.offsetWidth;die.style.animation='tumble 1.4s ease-out';
 let dl=40;skip=false;
 const end=()=>{n.textContent=val;die.style.animation='';die.classList.add('land');beep(val===sides?880:330,.25,.12);vib(val===sides?[40,40,90]:45);setTimeout(()=>{o.classList.remove('show');die.classList.remove('land');res()},850)};
 const tick=()=>{if(skip||dl>260)return end();n.textContent=1+R(sides);beep(180+R(220),.02,.03);vib(8);dl*=1.18;setTimeout(tick,dl)};tick()})}

// ===== محاسبات =====
let C=null,view='menu',tab='hub',sub='',F=null,CR=null,MSG=null,DR='',PG=0,SF='weapon',BF='all',QF='all',AD=null,ADS='weapon',ADQ='',ADM='forest',HELPOPEN=0;
const mr=()=>Math.max(C.rank,C.trank),maxComps=()=>2+Math.floor(C.trank/2);
function mig(c){const f=o=>typeof o==='string'?mk(o):o;c.eq=c.eq||{};c.inv=c.inv||[];c.comps=c.comps||[];c.tavern=c.tavern||[];for(const s in c.eq)c.eq[s]=f(c.eq[s]);c.inv=c.inv.map(f);
 const z={trank:0,trep:0,exps:0,evs:0,upgs:0,bk:0,stone:0,tower:0,qd:0,daily:''};for(const k in z)if(c[k]===undefined)c[k]=z[k];
 c.ks=c.ks||{};c.ka=c.ka||{};c.qs=c.qs||[];c.ach=c.ach||{};c.prog=c.prog||{};c.q=null;return c}
function calc(c){const s={...c.st};for(const sl in c.eq){const it=iv(c.eq[sl]);if(it.b)for(const k in it.b)s[k]=(s[k]||0)+it.b[k]}
 const Mo={};for(const k in s)Mo[k]=mod(s[k]);const cl=CLS[c.cls];
 const w=c.eq.weapon?iv(c.eq.weapon):{n:'مشت',st:'str',dm:[1,3,0]};const a=sl=>c.eq[sl]?(iv(c.eq[sl]).ac||0):0;
 const ac=10+Mo.spd+a('armor')+a('shield')+a('helm')+(c.cls==='knight'?1+Math.max(0,Math.floor(Mo.aura/2)):0);
 return{s,M:Mo,w,ac,hpMax:Math.max(6,cl.hp+(c.lvl-1)*cl.hpl+Mo.con*c.lvl),mpMax:4+c.lvl*2+Math.max(0,Mo[cl.key])*2,prof:2+Math.floor((c.lvl-1)/4)}}
function cst(p){const l=C.lvl,cl=CLS[p.cls],tb=C.trank;return{hp:Math.round((cl.hp+(l-1)*cl.hpl)*(1+p.tier*.3)),ac:11+Math.floor(l/2)+p.tier+Math.floor(tb/2),atk:2+Math.ceil(l/2)+p.tier+tb,dm:[1+Math.floor(l/6),cl.hp>=10?8:6,1+Math.floor(l/2)+p.tier+tb]}}
const cmax=p=>cst(p).hp;
function addXp(x){const L=[];C.xp+=x;while(C.xp>=thr(C.lvl)){C.lvl++;C.free+=2;const k=calc(C);C.hp=k.hpMax;C.mp=k.mpMax;L.push(`⬆️ لول ${C.lvl}! (+۲ امتیاز ویژگی)`);CLS[C.cls].ab.filter(a=>a.lv===C.lvl).forEach(a=>L.push('✨ مهارت جدید: '+a.n))}return L}
function loot(lv,boss,force){if(!force&&!boss&&R(100)>=38)return null;
 if(R(100)<(boss?15:28)){const t=Math.min(5,Math.floor(lv/5));return mk(R(3)?PH[Math.max(0,t-R(2))]:PM[Math.min(2,Math.floor(lv/8))])}
 const sl=SLOTS[R(7)][0];let t=Math.floor(lv/2.4)+(boss?1:0)+(R(100)<20?1:0)-(R(100)<25?1:0);t=Math.max(0,Math.min(9,t));
 const pool=Object.keys(ITEMS).filter(i=>ITEMS[i].t===sl&&ITEMS[i].tr===t);return mk(pool[R(pool.length)])}
function giveItem(o){if(C.inv.length>=80)return['🎒 کوله پر است!'];C.inv.push(o);const it=ITEMS[o.id];return[`🎁 ${it.e} ${it.n} (${RAR[it.r]})`]}
function genTavern(c){c.tavern=[];for(let i=0;i<4;i++){const x=R(100),tier=x<70?0:x<95?1:2,cls=Object.keys(CLS)[R(5)];c.tavern.push({id:Date.now()+i+R(9999),n:NAMES[R(NAMES.length)],cls,tier,e:CLS[cls].e,col:TCOL[tier]})}}
function qcnt(q){const t=q.t;return t==='sp'||t==='boss'?(C.ks[q.sp]||0):t==='area'?(C.ka[q.a]||0):t==='any'?C.kills:t==='bosses'?C.bk:t==='exp'?C.exps:t==='ev'?C.evs:t==='upg'?C.upgs:0}
const qprog=(q,a)=>Math.max(0,Math.min(q.cnt,qcnt(q)-a.base));
const doneQ=()=>C.qs.filter(a=>qprog(QUESTS.find(x=>x.id===a.id),a)>=QUESTS.find(x=>x.id===a.id).cnt).map(a=>a.id);

// ===== نمایش =====
const go=(v,t)=>{view=v;if(t)tab=t;sub='';PG=0;render();scrollTo(0,0)};
const bar=(v,m,c)=>`<div class="bar"><i style="width:${Math.max(0,Math.min(100,v/m*100))}%;background:${c}"></i><b>${fmt(Math.max(0,v))}/${fmt(m)}</b></div>`;
const bar2=(ic,v,m,c)=>`<div class="br"><span>${ic}</span>${bar(v,m,c)}</div>`;
const av=(c,sz=48)=>c.photo?`<img class="av" style="width:${sz}px;height:${sz}px" src="${c.photo}">`:`<div class="av" style="width:${sz}px;height:${sz}px;font-size:${sz*.5}px;background:${c.col||'#443'}">${c.e||CLS[c.cls].e}</div>`;
function render(){const a=$('#app');a.innerHTML=({menu:vMenu,create:vCreate,fight:vFight,msg:vMsg,help:vHelp,backup:vBackup,settings:vSettings,alogin:vALogin,admin:vAdmin})[view]?({menu:vMenu,create:vCreate,fight:vFight,msg:vMsg,help:vHelp,backup:vBackup,settings:vSettings,alogin:vALogin,admin:vAdmin})[view]():vMain()}
const tg=(k,n)=>`<label class="tg"><span>${n}</span><input type="checkbox" ${DB.set[k]?'checked':''} onchange="DB.set.${k}=this.checked?1:0;save()"></label>`;
const back=(t='← بازگشت')=>`<button class="b x" onclick="sub='';PG=0;render()">${t}</button>`;
function pager(total,per){const n=Math.ceil(total/per);if(n<=1)return'';return `<div class="row" style="justify-content:center"><button class="b sm" onclick="PG=Math.max(0,PG-1);render()">▶</button><span class="mut">${PG+1} / ${n}</span><button class="b sm" onclick="PG=Math.min(${n-1},PG+1);render()">◀</button></div>`}
const chips=(arr,cur,fn)=>`<div class="chips">${arr.map(([k,n])=>`<button class="chip ${cur===k?'on':''}" onclick="${fn}('${k}')">${n}</button>`).join('')}</div>`;

// --- منو ---
function vMenu(){const li=DB.chars.findIndex(c=>c.id===DB.last);
 return `<div class="hero"><div class="logo">${art({ty:'dragon',cl:['#2f9e44','#16601f','#e8b84a']})}</div><h1>D&amp;D</h1><div class="mut sm">سرزمین ماجراجویان · بازی نقش‌آفرینی آفلاین · بدون سقف لول</div></div>
${li>=0?`<button class="b big" onclick="play(${li})">▶️ ادامه‌ی ماجراجویی (${esc(DB.chars[li].name)})</button>`:''}
<div class="sech">⚔️ کاراکترها</div>
${DB.chars.map((c,i)=>`<div class="card row">${av(c,54)}<div class="grow"><b>${esc(c.name)}</b><div class="mut sm">${CLS[c.cls].n} ${RACES[c.race].n} · لول ${c.lvl}</div><div class="sm">رنک <span class="rk">${RANKS[c.rank]}</span> تیمی <span class="rk t">${RANKS[c.trank||0]}</span></div></div><button class="b" onclick="play(${i})">بازی</button><button class="b x" onclick="delC(${i})">🗑</button></div>`).join('')||'<div class="mut center">هنوز کاراکتری نداری</div>'}
<button class="b big" onclick="newC()">➕ کاراکتر جدید</button>
<div class="grid" style="margin-top:10px"><button class="tile s" onclick="go('backup')">💾<b>ذخیره و بازیابی</b></button><button class="tile s" onclick="go('help')">📖<b>راهنما</b></button><button class="tile s" onclick="go('settings')">⚙️<b>تنظیمات</b></button><button class="tile s" onclick="go('alogin')">🛠<b>ادمین</b></button></div>
<p class="mut sm center">قوانین بر پایه‌ی SRD 5.1 (CC-BY 4.0)</p>`}
function play(i){C=mig(DB.chars[i]);DB.last=C.id;tab='hub';const t=new Date().toDateString();let m='';if(C.daily!==t){C.daily=t;const g=100+C.lvl*30;C.gold+=g;C.stone+=1;m=`🎁 جایزه‌ی امروز: ${g} سکه و ۱ سنگ ارتقا`}save();go('main');if(m)toast(m)}
function delC(i){if(confirm('این کاراکتر برای همیشه پاک بشه؟')){DB.chars.splice(i,1);save();render()}}
function newC(){CR={name:'',photo:'',race:'human',cls:'fighter',free:12,add:{str:0,spd:0,con:0,mag:0,pow:0,aura:0}};go('create')}
const fin=k=>CLS[CR.cls].base[k]+(RACES[CR.race].b[k]||0)+CR.add[k];
function vCreate(){const cl=CLS[CR.cls];const keys=STATS.filter(([k])=>k!=='aura'||CR.cls==='knight');
 return `<div class="card"><h2>ساخت کاراکتر</h2><div class="center">${CR.photo?`<img class="av" style="width:96px;height:96px" src="${CR.photo}">`:`<div class="av" style="width:96px;height:96px;font-size:50px;background:#443">${cl.e}</div>`}<br><label class="b sm">📷 عکس از دوربین/گالری<input type="file" accept="image/*" hidden onchange="pickPhoto(this)"></label>${CR.photo?` <button class="b sm x" onclick="CR.photo='';render()">حذف</button>`:''}</div>
<input class="in" placeholder="اسم کاراکتر" value="${esc(CR.name)}" oninput="CR.name=this.value" maxlength="16">
<div class="mut">نژاد</div><div class="chips">${Object.entries(RACES).map(([k,r])=>`<button class="chip ${CR.race===k?'on':''}" onclick="CR.race='${k}';render()">${r.n}</button>`).join('')}</div>
<div class="mut">کلاس</div><div class="chips">${Object.entries(CLS).map(([k,c])=>`<button class="chip ${CR.cls===k?'on':''}" onclick="setCls('${k}')">${c.e} ${c.n}</button>`).join('')}</div>
<p class="sm mut">${cl.d}</p><div>امتیاز آزاد: <b class="rk">${CR.free}</b></div>
${keys.map(([k,n])=>`<div class="row"><span class="grow">${n}<div class="sm mut">${STD[k]}</div></span><button class="b sm" onclick="adj('${k}',-1)">−</button><b style="width:28px;text-align:center">${fin(k)}</b><button class="b sm" onclick="adj('${k}',1)">+</button></div>`).join('')}
<div class="row"><button class="b x" onclick="go('menu')">بازگشت</button><button class="b big grow" onclick="finish()">شروع (رنک F)</button></div></div>`}
function setCls(k){CR.cls=k;CR.free=12;for(const s in CR.add)CR.add[s]=0;render()}
function adj(k,v){if(v>0&&(CR.free<=0||fin(k)>=18))return;if(v<0&&CR.add[k]<=0)return;CR.add[k]+=v;CR.free-=v;render()}
function pickPhoto(inp){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const s=Math.min(im.width,im.height),cv=document.createElement('canvas');cv.width=cv.height=192;cv.getContext('2d').drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,192,192);CR.photo=cv.toDataURL('image/jpeg',.8);render()};im.src=r.result};r.readAsDataURL(f)}
function finish(){const n=CR.name.trim();if(!n)return toast('اسم بذار');const cl=CLS[CR.cls],st={};for(const [k] of STATS)st[k]=fin(k);
 const c=mig({id:Date.now(),name:n,photo:CR.photo,race:CR.race,cls:CR.cls,lvl:1,xp:0,st,free:CR.free,gold:50,rank:0,rep:0,kills:0,eq:{},inv:[],comps:[],tavern:[]});
 cl.kit.forEach(id=>{const it=ITEMS[id];if(it.t==='potion')c.inv.push(mk(id));else c.eq[it.t]=mk(id)});
 const k=calc(c);c.hp=k.hpMax;c.mp=k.mpMax;genTavern(c);DB.chars.push(c);DB.last=c.id;save();C=c;tab='hub';go('main')}

// --- صفحه‌ی اصلی ---
const TABS=[['hub','🏘️','شهر'],['map','🗺️','نقشه'],['bag','🎒','کوله'],['sheet','👤','کاراکتر'],['more','☰','بیشتر']];
function vMain(){const k=calc(C),pv=C.lvl>1?thr(C.lvl-1):0;
 const hd=`<div class="hd">${av(C,58)}<div class="grow"><div><b>${esc(C.name)}</b> <span class="rk">${RANKS[C.rank]}</span> <span class="rk t">${RANKS[C.trank]}</span></div><div class="mut sm">${CLS[C.cls].n} · لول ${C.lvl} · 🪙${fmt(C.gold)} · 💠${C.stone}</div>${bar2('❤️',C.hp,k.hpMax,'#c8453f')}${bar2('💧',C.mp,k.mpMax,CLS[C.cls].col)}${bar2('⭐',Math.max(0,C.xp-pv),thr(C.lvl)-pv,'#8a6bd1')}</div></div>`;
 const b=tab==='hub'?vHub():tab==='map'?vMap():tab==='bag'?vBag():tab==='sheet'?vSheet():vMore();
 return hd+`<div class="pg">${b}</div><nav>${TABS.map(([k,i,n])=>`<button class="${tab===k?'on':''}" onclick="tab='${k}';sub='';PG=0;render();scrollTo(0,0)">${i}<span>${n}</span></button>`).join('')}</nav>`}
function vMore(){
 if(sub==='dice')return back()+`<div class="card"><b>🎲 تاس‌انداز</b><div class="chips">${[4,6,8,10,12,20,100].map(s=>`<button class="chip" onclick="freeRoll(${s})">d${s}</button>`).join('')}</div><div class="big2">${DR}</div></div>`;
 if(sub==='ach')return vAch();if(sub==='best')return vBest();
 return `<div class="grid"><button class="tile" onclick="sub='ach';render()">🏆<b>دستاوردها</b></button><button class="tile" onclick="sub='best';render()">📚<b>دفترچه‌ی هیولاها</b></button><button class="tile" onclick="sub='dice';render()">🎲<b>تاس‌انداز</b></button><button class="tile" onclick="go('help')">📖<b>راهنما</b></button><button class="tile" onclick="go('backup')">💾<b>ذخیره و بازیابی</b></button><button class="tile" onclick="go('settings')">⚙️<b>تنظیمات</b></button><button class="tile" onclick="save();C=null;go('menu')">🚪<b>خروج به منو</b></button></div>`}
async function freeRoll(s){const r=d(s);await dice(s,r,'تاس آزاد');DR=`d${s} ← ${r}`;render()}
function vAch(){let h=back()+'<div class="card"><b>🏆 دستاوردها</b>';ACH.forEach(a=>{const ok=a.f(C),got=C.ach[a.id];h+=`<div class="row it ${ok||got?'':'dis'}"><div class="grow"><b>${a.n}</b><div class="sm mut">${a.d} · 🪙${fmt(a.g)}${a.s?' · 💠'+a.s:''}</div></div>${got?'✅':ok?`<button class="b sm" onclick="claim('${a.id}')">دریافت</button>`:'🔒'}</div>`});return h+'</div>'}
function claim(id){const a=ACH.find(x=>x.id===id);if(C.ach[id]||!a.f(C))return;C.ach[id]=1;C.gold+=a.g;C.stone+=a.s||0;save();toast('🏆 جایزه دریافت شد');render()}
function vBest(){let h=back()+'<div class="card"><b>📚 دفترچه‌ی هیولاها</b><div class="sm mut">با شکست دادن هر هیولا تصویرش آشکار می‌شه</div></div>';AKEYS.forEach(a=>{h+=`<div class="card"><b>${AREAS[a].e} ${AREAS[a].n}</b><div class="bgrid">`+[...AREAS[a].mon,AREAS[a].boss].map(m=>{const n=C.ks[m.n]||0;return `<div class="bm ${n?'':'unk'}"><div class="bart">${art(m)}</div><div class="sm">${n?m.n:'؟؟؟'}</div><div class="sm mut">${n?'کشته: '+n:''}</div></div>`}).join('')+'</div></div>'});return h}

// --- شهر ---
function vHub(){if(sub==='guild')return vGuild();if(sub==='shop')return vShop();if(sub==='tav')return vTav();if(sub==='smith')return vSmith();
 return `<div class="grid"><button class="tile" onclick="sub='guild';render()">📜<b>انجمن</b><span>کوئست و رنک</span></button><button class="tile" onclick="sub='shop';PG=0;render()">🏪<b>فروشگاه</b><span>خرید تجهیزات</span></button><button class="tile" onclick="sub='smith';PG=0;render()">🔨<b>آهنگری</b><span>ارتقای تجهیزات</span></button><button class="tile" onclick="sub='tav';render()">🍺<b>میخانه</b><span>استخدام هم‌تیمی</span></button><button class="tile" onclick="inn()">🛏️<b>مسافرخانه</b><span>${10*C.lvl} 🪙 استراحت کامل</span></button><button class="tile" onclick="go('help')">📖<b>راهنما</b><span>آموزش بازی</span></button></div>`}
function inn(){const cost=10*C.lvl;if(C.gold<cost)return toast('پول کافی نیست');C.gold-=cost;const k=calc(C);C.hp=k.hpMax;C.mp=k.mpMax;C.comps.forEach(p=>p.hp=cmax(p));save();toast('😴 استراحت کردی؛ همه چیز پر شد');render()}
function rankCard(kind){const so=kind==='s',rk=so?C.rank:C.trank,rp=so?C.rep:C.trep,nr=rk<8?rk+1:null;
 let h=`<div class="card"><h3>${so?'🧍 رنک انفرادی':'👥 رنک تیمی'}: <span class="rk ${so?'':'t'}">${RANKS[rk]}</span></h3><div class="sm mut">${so?'شهرت وقتی تنها می‌جنگی':'شهرت وقتی هم‌تیمی همراهته'}: ${rp}</div>`;
 if(nr!==null){const need=RANKREP[nr],lv=nr*2;h+=bar(Math.min(rp,need),need,so?'#e8b84a':'#4a90d9')+`<div class="sm mut">رنک بعدی ${RANKS[nr]}: شهرت ${need} و لول ${lv}</div>`;if(rp>=need&&C.lvl>=lv)h+=`<button class="b big" onclick="exam('${kind}')">⚔️ آزمون رنک ${RANKS[nr]}</button>`}else h+='<div>🏆 بالاترین رنک!</div>';
 return h+`<div class="sm">${so?`مزیت: ${Math.floor(C.rank/2)}+ دقت و ${C.rank}+ آسیب وقتی تنها می‌جنگی`:`مزیت: هم‌تیمی‌ها ${C.trank}+ قوی‌تر · حداکثر ${maxComps()} هم‌تیمی`}</div></div>`}
function exam(k){const so=k==='s',n=(so?C.rank:C.trank)+1;if(!so&&!C.comps.length)return toast('برای آزمون تیمی حداقل یه هم‌تیمی لازمه');
 const m=MON('آزمون‌گر رنک '+RANKS[n],'knight',['#9aa5b1','#4a5560','#ffd34d'],n*2+(so?1:0),'t',so?0:1);startFight(m,'exam',so?'exam-s':'exam-t',{solo:so})}
const QCATS=[['all','همه'],['sp','گونه‌ها'],['area','مناطق'],['boss','باس‌ها'],['misc','متفرقه']];
function vGuild(){let h=back('← بازگشت به شهر')+rankCard('s')+rankCard('t');
 h+=`<div class="card"><b>📜 کوئست‌های فعال (${C.qs.length}/3)</b>`;
 C.qs.forEach(a=>{const q=QUESTS.find(x=>x.id===a.id),p=qprog(q,a);h+=`<div class="it"><b>${q.n}</b><div class="sm mut">${q.d}</div>${bar(p,q.cnt,'#5aa75a')}<div class="sm">🪙${fmt(q.g)} ⭐${fmt(q.x)} 🏅${q.rep}</div>${p>=q.cnt?`<button class="b big" onclick="turnIn('${q.id}')">تحویل و دریافت جایزه</button>`:`<button class="b sm x" onclick="dropQ('${q.id}')">لغو</button>`}</div>`});
 if(!C.qs.length)h+='<div class="mut sm">کوئستی نداری. از تابلوی پایین یکی بردار.</div>';h+='</div>';
 const list=QUESTS.filter(q=>q.rank<=mr()&&!C.qs.find(a=>a.id===q.id)&&(QF==='all'||q.cat===QF)).sort((a,b)=>a.rank-b.rank);
 h+=`<div class="card"><b>📋 تابلوی کوئست (${list.length})</b>${chips(QCATS,QF,'setQF')}`+list.slice(PG*8,PG*8+8).map(q=>`<div class="it"><b>${q.n}</b> <span class="rk">${RANKS[q.rank]}</span><div class="sm mut">${q.d}</div><div class="row"><span class="sm grow">🪙${fmt(q.g)} ⭐${fmt(q.x)} 🏅${q.rep}</span><button class="b sm ${C.qs.length>=3?'dis':''}" onclick="takeQ('${q.id}')">قبول</button></div></div>`).join('')+pager(list.length,8)+'</div>';return h}
function setQF(k){QF=k;PG=0;render()}
function takeQ(id){if(C.qs.length>=3)return toast('حداکثر ۳ کوئست همزمان');const q=QUESTS.find(x=>x.id===id);C.qs.push({id,base:qcnt(q)});save();render()}
function dropQ(id){C.qs=C.qs.filter(a=>a.id!==id);save();render()}
function turnIn(id){const q=QUESTS.find(x=>x.id===id);C.gold+=q.g;const tm=C.comps.length>0;if(tm)C.trep+=q.rep;else C.rep+=q.rep;C.qd++;
 const L=[`🪙 ${fmt(q.g)} سکه`,`⭐ ${fmt(q.x)} تجربه`,`🏅 ${q.rep} شهرت ${tm?'تیمی':'انفرادی'}`,...addXp(q.x)];C.qs=C.qs.filter(a=>a.id!==id);if(R(100)<30){const o=loot(AREAS[q.a]?AREAS[q.a].lv:C.lvl,false,true);if(o)L.push(...giveItem(o))}genTavern(C);save();msg('✅ کوئست تموم شد',L,'hub')}
function vShop(){const lim=Math.min(9,mr()+1+Math.floor(C.lvl/12));let h=back('← بازگشت به شهر')+`<div class="card"><b>🏪 فروشگاه</b> <span class="mut">🪙 ${fmt(C.gold)}</span>${chips([...SLOTS,['potion','معجون'],['stone','سنگ']],SF,'setSF')}`;
 if(SF==='stone')h+=[1,5,20].map(n=>`<div class="row it"><div class="grow">💠 ${n} سنگ ارتقا<div class="sm mut">برای ارتقای تجهیزات در آهنگری</div></div><button class="b sm ${C.gold<n*150?'dis':''}" onclick="buyStone(${n})">🪙${fmt(n*150)}</button></div>`).join('');
 else{const ids=Object.keys(ITEMS).filter(i=>ITEMS[i].t===SF&&ITEMS[i].tr!==undefined&&ITEMS[i].tr<=lim).sort((a,b)=>ITEMS[a].p-ITEMS[b].p);
  h+=ids.slice(PG*10,PG*10+10).map(id=>`<div class="row it">${itemLine(mk(id))}<button class="b sm ${C.gold<ITEMS[id].p?'dis':''}" onclick="buy('${id}')">🪙${fmt(ITEMS[id].p)}</button></div>`).join('')+pager(ids.length,10)+`<div class="sm mut">با بالاتر رفتن رنک و لول، تجهیزات قوی‌تر باز می‌شن.</div>`}
 return h+'</div>'}
function setSF(k){SF=k;PG=0;render()}
function buy(id){const it=ITEMS[id];if(C.gold<it.p)return toast('پول کافی نیست');if(C.inv.length>=80)return toast('کوله پره');C.gold-=it.p;C.inv.push(mk(id));save();toast('خریدی: '+it.n);render()}
function buyStone(n){if(C.gold<n*150)return toast('پول کافی نیست');C.gold-=n*150;C.stone+=n;save();render()}
function vTav(){let h=back('← بازگشت به شهر')+`<div class="card"><b>👥 هم‌تیمی‌ها (${C.comps.length}/${maxComps()})</b>`+(C.comps.map((p,i)=>`<div class="row">${av(p,40)}<div class="grow"><b>${p.n}</b><div class="sm mut">${CLS[p.cls].n} · ${TIER[p.tier]}</div></div><button class="b sm x" onclick="C.comps.splice(${i},1);save();render()">اخراج</button></div>`).join('')||'<div class="mut sm">کسی همراهت نیست</div>')+'</div>';
 const mul=1+Math.floor(C.lvl/5);h+=`<div class="card"><b>🍺 افراد توی میخانه</b>`+C.tavern.map((p,i)=>`<div class="row">${av(p,40)}<div class="grow"><b>${p.n}</b><div class="sm mut">${CLS[p.cls].n} · <span style="color:${RCOL[p.tier*2]}">${TIER[p.tier]}</span></div></div><button class="b sm" onclick="hire(${i})">🪙${fmt(TP[p.tier]*mul)}</button></div>`).join('')+`<button class="b x" onclick="newTav()">🔄 افراد جدید (50🪙)</button></div>`;return h}
function hire(i){const p=C.tavern[i],cost=TP[p.tier]*(1+Math.floor(C.lvl/5));if(C.comps.length>=maxComps())return toast('جا نداری؛ با رنک تیمی بالاتر جای بیشتر باز می‌شه');if(C.gold<cost)return toast('پول کافی نیست');C.gold-=cost;C.tavern.splice(i,1);const q={...p};q.hp=cmax(q);C.comps.push(q);save();render()}
function newTav(){if(C.gold<50)return toast('پول کافی نیست');C.gold-=50;genTavern(C);save();render()}
// --- آهنگری ---
function vSmith(){let h=back('← بازگشت به شهر')+`<div class="card"><b>🔨 آهنگری</b> <span class="mut">🪙${fmt(C.gold)} · 💠${C.stone}</span><div class="sm mut">هر ارتقا آیتم رو قوی‌تر می‌کنه (حداکثر +${UMAX}). اگه ناموفق شد آیتم خراب نمی‌شه، فقط هزینه از دست می‌ره.</div></div>`;
 const list=[];SLOTS.forEach(([s])=>{if(C.eq[s])list.push({o:C.eq[s],w:'eq:'+s,e:1})});C.inv.forEach((o,i)=>{if(ITEMS[o.id].t!=='potion')list.push({o,w:'inv:'+i})});
 h+=list.slice(PG*6,PG*6+6).map(({o,w,e})=>{const u=o.u||0,mx=u>=UMAX,c=upCost(o),nx=mx?null:{id:o.id,u:u+1};return `<div class="card"><div class="row">${itemLine(o)}${e?'<span class="sm">🟢 پوشیده</span>':''}</div>${mx?'<div class="rk">حداکثر ارتقا</div>':`<div class="sm">بعد از ارتقا: ${desc(nx)}</div><div class="row"><span class="sm grow">🪙${fmt(c.g)} · 💠${c.s} · شانس ${c.c}٪</span><button class="b sm ${C.gold<c.g||C.stone<c.s?'dis':''}" onclick="upgrade('${w}')">ارتقا</button></div>`}</div>`}).join('')+pager(list.length,6);
 return h}
async function upgrade(w){const [t,i]=w.split(':'),o=t==='eq'?C.eq[i]:C.inv[+i];if(!o)return;const u=o.u||0;if(u>=UMAX)return;const c=upCost(o);if(C.gold<c.g||C.stone<c.s)return toast('منابع کافی نیست');
 C.gold-=c.g;C.stone-=c.s;const r=d(100);await dice(100,r,'ارتقا (شانس '+c.c+'٪)');if(r<=c.c){o.u=u+1;C.upgs++;toast('✅ ارتقا موفق! '+ITEMS[o.id].n+' +'+o.u);beep(880,.3,.1)}else toast('❌ ارتقا ناموفق بود');save();render()}
// --- نقشه ---
function vMap(){let h='';AKEYS.forEach(a=>{const A=AREAS[a],lock=mr()<A.rank,p=C.prog[a]||0;h+=`<div class="card ar" style="background:linear-gradient(135deg,${A.col},var(--card))"><div class="row"><span class="em2">${A.e}</span><div class="grow"><b>${A.n}</b><div class="sm mut">لول پیشنهادی ${A.lv}${lock?' · 🔒 رنک '+RANKS[A.rank]:''}</div></div></div>${lock?'':`${bar(Math.min(p,4),4,'#e8b84a')}<div class="row"><button class="b grow" onclick="explore('${a}')">🧭 کاوش</button>${p>=4?`<button class="b red" onclick="startFight(AREAS['${a}'].boss,'${a}','boss')">👑 ${AREAS[a].boss.n}</button>`:''}</div>`}</div>`});
 return h+`<div class="card ar" style="background:linear-gradient(135deg,#3a2a55,var(--card))"><div class="row"><span class="em2">🗼</span><div class="grow"><b>برج بی‌پایان</b><div class="sm mut">طبقه‌ی بعدی: ${C.tower+1}${(C.tower+1)%10===0?' · 👑 باس':''} · رکورد: ${C.tower}</div></div></div>${C.lvl<5?'<div class="sm mut">🔒 لول ۵ لازمه</div>':`<button class="b big" onclick="startTower()">ورود به طبقه ${C.tower+1}</button>`}</div>`}
function startTower(){const f=C.tower+1,boss=f%10===0,pool=ALLM.filter(x=>!!x.m.boss===boss),b=pool[R(pool.length)].m,m=MON(b.n,b.ty,b.cl,3+f,b.ro,boss?1:0);m.fl=f;startFight(m,'tower','tower')}
function msg(t,l,bk='map'){MSG={t,l,opts:null,bk};view='msg';render();scrollTo(0,0)}
function vMsg(){return `<div class="card"><h3>${MSG.t}</h3>${MSG.l.map(x=>`<p>${x}</p>`).join('')}${MSG.opts?MSG.opts.map((o,i)=>`<button class="b big" onclick="resolveEv(${i})">${o.s?'🎲 ':''}${o.l}${o.s?` (${STN[o.s]}، سختی ${o.dc+MSG.tier})`:''}</button>`).join(''):`<button class="b big" onclick="go('main','${MSG.bk}')">ادامه</button>`}</div>`}
function explore(a){const A=AREAS[a];C.prog[a]=(C.prog[a]||0)+1;C.exps++;const x=R(100);save();
 if(x<55)return startFight(A.mon[R(A.mon.length)],a,'mon');
 if(x<68){const g=Math.round(15+A.lv*14+R(20)),L=['📦 صندوقی پیدا کردی!','🪙 '+g+' سکه'];C.gold+=g;const o=loot(A.lv,false,R(2)?true:false);if(o)L.push(...giveItem(o));save();return msg('📦 گنج',L)}
 if(x<88){const ev=EVENTS[R(EVENTS.length)];MSG={t:ev.t,l:[ev.d],opts:ev.o,ev,tier:Math.floor(A.lv/2),a,bk:'map'};view='msg';render();return}
 const k=calc(C);C.hp=Math.min(k.hpMax,C.hp+Math.ceil(k.hpMax*.2));C.mp=Math.min(k.mpMax,C.mp+Math.ceil(k.mpMax*.3));save();msg('🏕️ جای امن',['استراحت کوتاهی کردی و کمی جان و منبع پس گرفتی.'])}
async function resolveEv(i){const o=MSG.ev.o[i],t=MSG.tier,ev=MSG.ev,A=AREAS[MSG.a];if(!o.s)return msg(ev.t,['از کنارش گذشتی.']);
 const k=calc(C),r=d(20),dc=o.dc+t;await dice(20,r,o.l);const m=k.M[o.s],tot=r+m,ok=r===20||(r>1&&tot>=dc);C.evs++;const L=[`🎲 ${r} ${sg(m)} = ${tot} (سختی ${dc})`];
 if(ok){const g=Math.round(15+A.lv*14+R(25)),x=10+A.lv*12;C.gold+=g;L.push('✅ موفق شدی!','🪙 '+g+' سکه','⭐ '+x+' تجربه');if(o.item||R(100)<30){const it=loot(A.lv,false,true);if(it)L.push(...giveItem(it))}L.push(...addXp(x))}
 else{const dm=roll(1+Math.ceil(A.lv/3),6);C.hp=Math.max(1,C.hp-dm);L.push(`❌ شکست خوردی و ${dm} آسیب دیدی`)}
 save();msg(ev.t,L)}

// --- کوله ---
function itemLine(o){const it=ITEMS[o.id];return `<div class="grow"><span style="color:${RCOL[it.r]}">${it.e} ${it.n}${o.u?` <b>+${o.u}</b>`:''}</span><div class="sm mut">${desc(o)}</div></div>`}
const BFC=[['all','همه'],...SLOTS,['potion','معجون']];
function vBag(){let h='<div class="card"><b>🛡️ پوشیده‌ها</b>';
 SLOTS.forEach(([s,n])=>{const o=C.eq[s];h+=`<div class="row it">${o?itemLine(o)+`<button class="b sm" onclick="unequip('${s}')">درآوردن</button>`:`<span class="mut grow">${n}: خالی</span>`}</div>`});
 h+=`</div><div class="card"><b>🎒 کوله (${C.inv.length}/80)</b>${chips(BFC,BF,'setBF')}`;
 const ent=[],seen={};C.inv.forEach((o,i)=>{const it=ITEMS[o.id];if(BF!=='all'&&it.t!==BF)return;if(it.t==='potion'){if(seen[o.id]){seen[o.id].n++;return}seen[o.id]={o,i,n:1};ent.push(seen[o.id])}else ent.push({o,i,n:1})});
 h+=ent.slice(PG*12,PG*12+12).map(({o,i,n})=>{const it=ITEMS[o.id],p=it.t==='potion',cur=C.eq[it.t],cmp=!p&&cur?(score(o)>score(cur)?'<span style="color:#5cb85c">▲</span> ':score(o)<score(cur)?'<span style="color:#d9534f">▼</span> ':''):'';
  return `<div class="row it">${cmp}${itemLine(o)}${n>1?`<b>×${n}</b>`:''}<button class="b sm" onclick="${p?'usePot':'equip'}(${i})">${p?'مصرف':'بپوش'}</button><button class="b sm x" onclick="sell(${i})">🪙${fmt(sellP(o))}</button></div>`}).join('')+pager(ent.length,12);
 return h+(ent.length?'':'<div class="mut">خالی</div>')+'</div>'}
function setBF(k){BF=k;PG=0;render()}
function clampHp(){const k=calc(C);C.hp=Math.min(C.hp,k.hpMax);C.mp=Math.min(C.mp,k.mpMax)}
function equip(i){const o=C.inv[i],s=ITEMS[o.id].t,old=C.eq[s];C.inv.splice(i,1);if(old)C.inv.push(old);C.eq[s]=o;clampHp();save();render()}
function unequip(s){if(C.inv.length>=80)return toast('کوله پره');C.inv.push(C.eq[s]);delete C.eq[s];clampHp();save();render()}
function sell(i){C.gold+=sellP(C.inv[i]);C.inv.splice(i,1);save();render()}
function applyPot(id){const it=ITEMS[id],k=calc(C);if(it.heal)C.hp=Math.min(k.hpMax,C.hp+it.heal);if(it.mpr)C.mp=Math.min(k.mpMax,C.mp+it.mpr)}
function usePot(i){applyPot(C.inv[i].id);C.inv.splice(i,1);save();render()}

// --- کاراکتر ---
function vSheet(){const k=calc(C),cl=CLS[C.cls];let h=`<div class="card"><b>📊 ویژگی‌ها</b> ${C.free?`<span class="rk">امتیاز آزاد: ${C.free}</span>`:''}`;
 STATS.filter(([s])=>s!=='aura'||C.cls==='knight').forEach(([s,n])=>{h+=`<div class="row"><span class="grow">${n}<div class="sm mut">${STD[s]}</div></span><b>${k.s[s]}</b><span class="mut">(${sg(k.M[s])})</span>${C.free?`<button class="b sm" onclick="C.st['${s}']++;C.free--;save();render()">+</button>`:''}</div>`});
 h+=`</div><div class="card"><b>⚔️ جنگ</b><div class="row"><span class="grow">جان</span>${fmt(k.hpMax)}</div><div class="row"><span class="grow">${cl.res}</span>${fmt(k.mpMax)}</div><div class="row"><span class="grow">زره</span>${k.ac}</div><div class="row"><span class="grow">مهارت پایه</span>+${k.prof}</div><div class="row"><span class="grow">سلاح</span>${k.w.n}</div></div>`;
 h+=`<div class="card"><b>✨ مهارت‌های ${cl.n}</b>`+cl.ab.map(a=>`<div class="row ${C.lvl<a.lv?'dis':''}"><span class="grow">${a.n}<div class="sm mut">${a.k==='heal'?'درمان':'آسیب اضافه'} ${rng(a.x)} · هزینه ${a.c}</div></span>${C.lvl<a.lv?'🔒 لول '+a.lv:'✅'}</div>`).join('')+'</div>';
 return h+`<div class="card"><b>🏆 آمار</b><div>انفرادی ${RANKS[C.rank]} (شهرت ${C.rep}) · تیمی ${RANKS[C.trank]} (شهرت ${C.trep})</div><div>کشته‌ها ${fmt(C.kills)} · باس‌ها ${C.bk} · رکورد برج ${C.tower}</div></div>`}

// ===== مبارزه =====
const party=()=>F.solo?[]:C.comps;
function startFight(m,area,kind,opt={}){F={m:{...m,max:m.hp},area,kind,solo:!!opt.solo,log:[],busy:0,over:null,res:[],fx:null};const k=calc(C),a=d(20)+k.M.spd,b=d(20);
 lg(`${m.n} جلوت ظاهر شد!${m.fl?' (طبقه '+m.fl+')':''}`);lg(`🎲 ابتکار عمل: تو ${a} — دشمن ${b}`);view='fight';if(b>a){lg('⚠️ دشمن زودتر حمله کرد');enemyAtk()}render();scrollTo(0,0)}
const lg=t=>F.log.push(t);
function vFight(){const k=calc(C),m=F.m,pc=(x,hp,mx)=>`<div class="pc ${hp<=0?'dead':''}">${av(x,38)}${esc(x.name||x.n)}${bar(hp,mx,'#c8453f')}</div>`;
 let h=`<div class="enemy ${F.fx?'hit':''}" style="--ec:${m.cl[2]}"><div class="eart">${art(m)}${F.fx?`<div class="dmg ${F.fx.c?'crit':''}">−${fmt(F.fx.n)}</div>`:''}</div><b>${m.n}</b> <span class="mut sm">لول ${m.lv} · زره ${m.ac}</span>${bar(m.hp,m.max,'#c8453f')}</div>`;
 h+=`<div class="party ${F.hurt?'hurt':''}">${pc(C,C.hp,k.hpMax)}${party().map(p=>pc(p,p.hp,cmax(p))).join('')}</div><div class="sm mut" style="margin-top:6px">${CLS[C.cls].res}: ${C.mp}/${k.mpMax}${F.solo?' · 🧍 آزمون انفرادی':''}</div><div class="log">${F.log.slice(-7).map(l=>`<div>${l}</div>`).join('')}</div>`;
 if(F.over)return h+`<div class="card"><h3>${F.over==='win'?'🎉 پیروزی!':F.over==='lose'?'💀 شکست خوردی':'🏃 فرار کردی'}</h3>${F.res.map(r=>`<div>${r}</div>`).join('')}<button class="b big" onclick="endFight()">ادامه</button></div>`;
 h+='<div class="acts"><button class="b" onclick="pAct(-1)">⚔️ حمله</button>';
 CLS[C.cls].ab.forEach((a,i)=>{if(C.lvl>=a.lv)h+=`<button class="b ${C.mp<a.c&&!DB.set.fm?'dis':''}" onclick="pAct(${i})">✨ ${a.n} <small>(${a.c})</small></button>`});
 [...new Set(C.inv.filter(o=>ITEMS[o.id].t==='potion').map(o=>o.id))].forEach(id=>h+=`<button class="b" onclick="fPot('${id}')">${ITEMS[id].e} ${ITEMS[id].n} ×${C.inv.filter(o=>o.id===id).length}</button>`);
 return h+'<button class="b x" onclick="flee()">🏃 فرار</button></div>'}
async function pAct(i){if(F.busy||F.over)return;const k=calc(C),cl=CLS[C.cls],ab=i>=0?cl.ab[i]:null,cost=ab&&!DB.set.fm?ab.c:0;if(ab&&C.mp<cost)return toast('منبع کافی نیست');
 F.busy=1;F.fx=null;F.hurt=0;C.mp-=cost;
 if(ab&&ab.k==='heal'){const h=roll(ab.x[0],ab.x[1])+Math.max(0,k.M[cl.key]);C.hp=Math.min(k.hpMax,C.hp+h);lg(`💚 ${ab.n}: ${h}+ جان`);beep(660,.2)}
 else{const st=ab&&ab.k==='spell'?'mag':k.w.st,r=d(20),sb=party().length?0:Math.floor(C.rank/2),bn=k.M[st]+k.prof+sb;await dice(20,r,ab?ab.n:'حمله');const tot=r+bn,hit=r===20||(r>1&&tot>=F.m.ac);
  if(!hit)lg(`🎲 ${r}${sg(bn)}=${tot} (زره دشمن ${F.m.ac}) ❌ خطا رفت`);
  else{let dd,bd;if(!ab){dd=roll(k.w.dm[0],k.w.dm[1]);bd=k.M[k.w.st]+k.w.dm[2]}else if(ab.k==='spell'){dd=roll(ab.x[0],ab.x[1]);bd=Math.max(0,k.M.mag)}else{dd=roll(k.w.dm[0],k.w.dm[1])+roll(ab.x[0],ab.x[1]);bd=k.M[k.w.st]+k.w.dm[2]+Math.max(0,k.M.pow)}
   if(!party().length)bd+=C.rank;if(r===20)dd*=2;let dm=Math.max(1,dd+bd);if(DB.set.ohk)dm=F.m.hp;F.m.hp-=dm;F.fx={n:Math.min(dm,F.m.hp+dm),c:r===20};lg(`🎲 ${r}${sg(bn)}=${tot} (زره دشمن ${F.m.ac}) ${r===20?'💥 بحرانی! ':''}✅ ${dm} آسیب`)}}
 C.mp=Math.min(k.mpMax,C.mp+1+Math.floor(C.lvl/10));
 if(F.m.hp<=0){win();F.busy=0;return render()}
 render();await wait(450);F.fx=null;enemyPhase();F.busy=0;render()}
function fPot(id){if(F.busy||F.over)return;const i=C.inv.findIndex(o=>o.id===id);if(i<0)return;F.busy=1;F.fx=null;applyPot(id);C.inv.splice(i,1);lg(`${ITEMS[id].e} ${ITEMS[id].n} مصرف شد`);beep(520,.2);render();setTimeout(()=>{enemyPhase();F.busy=0;render()},450)}
async function flee(){if(F.busy||F.over)return;if(F.kind.startsWith('exam'))return toast('از آزمون نمی‌شه فرار کرد');F.busy=1;F.fx=null;const r=d(20),k=calc(C);await dice(20,r,'فرار');
 if(r+k.M.spd>=11){lg('🏃 فرار کردی');F.over='flee';F.busy=0;save();return render()}lg('❌ فرار ناموفق بود');render();await wait(400);enemyPhase();F.busy=0;render()}
function enemyPhase(){if(F.over)return;const k=calc(C);
 for(const p of party()){if(p.hp<=0||F.over)continue;const s=cst(p);
  if(p.cls==='cleric'&&C.hp<k.hpMax*.5&&R(2)){const h=roll(2,8)+C.lvl;C.hp=Math.min(k.hpMax,C.hp+h);lg(`💚 ${p.n} تو رو درمان کرد (${h}+)`);continue}
  const r=d(20);if(r===20||(r>1&&r+s.atk>=F.m.ac)){const dm=Math.max(1,roll(s.dm[0],s.dm[1])*(r===20?2:1)+s.dm[2]);F.m.hp-=dm;lg(`${p.e} ${p.n}: ${dm} آسیب`);if(F.m.hp<=0)return win()}else lg(`${p.e} ${p.n}: خطا`)}
 enemyAtk()}
function enemyAtk(){if(F.over)return;const m=F.m,k=calc(C),al=['p','p',...party().filter(p=>p.hp>0)],t=al[R(al.length)];
 const ac=t==='p'?k.ac:cst(t).ac+(C.cls==='knight'?1+Math.floor(k.M.aura/3):0),nm=t==='p'?C.name:t.n,r=d(20);
 if(r===20||(r>1&&r+m.atk>=ac)){let dm=Math.max(1,roll(m.d[0],m.d[1])*(r===20?2:1)+m.d[2]);if(t==='p'){if(DB.set.god)dm=0;C.hp-=dm;F.hurt=1;vib(60)}else t.hp-=dm;lg(`${m.n} به ${nm} ${dm} آسیب زد${r===20?' (بحرانی!)':''}`)}
 else lg(`${m.n} به ${nm} حمله کرد: خطا`);
 if(C.hp<=0)lose()}
function win(){if(F.over)return;F.over='win';const m=F.m,ex=F.kind.startsWith('exam'),L=[],g=Math.round(m.g*(.7+Math.random()*.6)),x=m.xp,rp=Math.max(1,Math.round(x/12)),b4=doneQ();
 C.gold+=g;L.push(`🪙 ${fmt(g)} سکه`,`⭐ ${fmt(x)} تجربه`);
 if(!ex){C.kills++;C.ks[m.n]=(C.ks[m.n]||0)+1;if(AREAS[F.area])C.ka[F.area]=(C.ka[F.area]||0)+1;if(m.boss)C.bk++;
  const tm=party().length>0;if(tm)C.trep+=rp;else C.rep+=rp;L.push(`🏅 ${rp} شهرت ${tm?'تیمی':'انفرادی'}`);
  if(R(100)<25+(m.boss?75:0)){const n=1+R(2)+(m.boss?2:0);C.stone+=n;L.push(`💠 ${n} سنگ ارتقا`)}
  if(F.kind==='boss')C.prog[F.area]=0;if(F.kind==='tower'){C.tower=Math.max(C.tower,m.fl);L.push('🗼 طبقه '+m.fl+' پاک شد')}
  const o=loot(m.lv,!!m.boss);if(o)L.push(...giveItem(o))}
 else{if(F.kind==='exam-s')C.rank++;else C.trank++;L.push(`🎖️ ارتقا به رنک ${RANKS[F.kind==='exam-s'?C.rank:C.trank]}!`)}
 L.push(...addXp(x));doneQ().filter(id=>!b4.includes(id)).forEach(id=>L.push('📜 کوئست «'+QUESTS.find(q=>q.id===id).n+'» آماده‌ی تحویله!'));
 C.comps.forEach(p=>{if(p.hp<=0)p.hp=1});F.res=L;lg(`☠️ ${m.n} شکست خورد`);beep(784,.3,.1);save()}
function lose(){if(F.over)return;F.over='lose';const k=calc(C),l=Math.floor(C.gold*.2);C.gold-=l;C.hp=Math.max(1,Math.floor(k.hpMax/2));C.mp=k.mpMax;C.comps.forEach(p=>{if(p.hp<=0)p.hp=1});F.res=['به شهر برگردونده شدی.',`🪙 ${fmt(l)} سکه از دست دادی`];save()}
function endFight(){const t=F.over==='lose'||F.kind.startsWith('exam')?'hub':F.kind==='tower'?'map':'map';F=null;go('main',t)}

// ===== تنظیمات / راهنما =====
function vSettings(){return `<button class="b x" onclick="go(C?'main':'menu')">← بازگشت</button><div class="card"><b>⚙️ تنظیمات</b>${tg('anim','انیمیشن تاس')}${tg('snd','صدا')}${tg('vib','ویبره')}</div>
<button class="b big" onclick="go('backup')">💾 ذخیره و بازیابی اکانت</button>`}
const HELP=[['🎯 شروع بازی','کاراکتر بساز (عکس دلخواه، نژاد، کلاس و ویژگی‌ها). از رنک F شروع می‌کنی. توی شهر کوئست بگیر، تجهیزات بخر و از نقشه برای کاوش و مبارزه برو. بازی سقف لول نداره و خودکار ذخیره می‌شه.'],
['📊 ویژگی‌ها','قدرت بدنی: آسیب سلاح سنگین · سرعت: زره و ابتکار عمل · استقامت: جان · جادو: جادو و درمان · نیرو: آسیب مهارت‌های ویژه · هاله: فقط شوالیه. با هر لول ۲ امتیاز آزاد می‌گیری و از تب «کاراکتر» خرجش می‌کنی.'],
['⚔️ مبارزه','نوبتی‌ه. تاس d20 می‌اندازی؛ اگه عدد تاس + مهارتت از «زره دشمن» بیشتر یا مساوی باشه ضربه می‌خوره. ۲۰ بحرانیه (آسیب دو برابر) و ۱ همیشه خطاست. مهارت‌ها منبع (انرژی/مانا/هاله) خرج می‌کنن و هر نوبت کمی برمی‌گرده.'],
['🎲 تاس','نتیجه‌ی تاس اول تعیین می‌شه و بعد انیمیشن روی همون عدد می‌ایسته. با تپ روی صفحه انیمیشن رو رد کن. از تنظیمات می‌تونی خاموشش کنی.'],
['🛡️ تجهیزات و ارتقا','هر آیتم ۱۰ مرحله داره (کهنه تا کیهانی). زیر هر آیتم نوشته چه کمکی می‌کنه. فلش ▲ سبز یعنی از چیزی که پوشیدی قوی‌تره. توی آهنگری با سکه و «سنگ ارتقا» تا +۱۵ ارتقا بده؛ شانس موفقیت با بالا رفتن کمتر می‌شه ولی آیتم هیچ‌وقت خراب نمی‌شه. سنگ از هیولاها می‌افته یا از فروشگاه می‌خری.'],
['🏅 رنک انفرادی و تیمی','دو رنک مستقل داری (F تا SSS). شهرت انفرادی وقتی بدون هم‌تیمی می‌جنگی و شهرت تیمی وقتی هم‌تیمی همراهته جمع می‌شه. وقتی شهرت و لول کافی شد، توی انجمن آزمون رنک بده (آزمون تیمی حداقل یه هم‌تیمی می‌خواد). مزیت انفرادی: دقت و آسیب بیشتر وقتی تنهایی. مزیت تیمی: هم‌تیمی‌های قوی‌تر و جای بیشتر برای استخدام. مناطق جدید با بالاترین رنک بین این دو باز می‌شن.'],
['📜 کوئست‌ها','انجمن بیش از صد کوئست داره: شکار گونه‌ی مشخص (گرگ، گابلین...)، پاکسازی منطقه، باس‌ها و کارهای متفرقه. تا ۳ کوئست همزمان می‌تونی داشته باشی. پیشرفت خودکار حساب می‌شه؛ وقتی کامل شد توی انجمن تحویل بده.'],
['👥 هم‌تیمی‌ها','توی میخانه استخدام کن. هم‌تیمی‌ها با لول تو قوی می‌شن و کنارت می‌جنگن. کشیش‌ها درمان هم می‌کنن.'],
['🗼 برج بی‌پایان','از لول ۵ باز می‌شه. هر طبقه هیولای قوی‌تری داره و هر ۱۰ طبقه یه باس. جایزه‌ها با طبقه بیشتر می‌شن.'],
['💡 نکته‌ها','قبل از باس حتماً توی مسافرخانه استراحت کن. معجون همراه داشته باش. اگه شکست بخوری ۲۰٪ سکه‌ات رو از دست می‌دی. هر روز با اولین ورود یه جایزه‌ی روزانه می‌گیری. از دفترچه‌ی هیولاها پیشرفتت رو ببین.']];
function vHelp(){return `<button class="b x" onclick="go(C?'main':'menu')">← بازگشت</button><div class="card"><h2>📖 راهنمای بازی</h2>${HELP.map(([t,b])=>`<details class="hp"><summary>${t}</summary><p>${b}</p></details>`).join('')}</div>`}


// ===== ذخیره و بازیابی اکانت =====
let PB=null;
const stamp=()=>new Date().toISOString().slice(0,10);
function mkBackup(ids){const set={anim:DB.set.anim,snd:DB.set.snd,vib:DB.set.vib};return JSON.stringify({app:'DnD',v:2,date:new Date().toISOString(),chars:ids?DB.chars.filter(c=>ids.includes(c.id)):DB.chars,set:ids?undefined:set})}
async function exportFile(ids,name){const txt=mkBackup(ids),P=window.Capacitor&&Capacitor.Plugins;
 try{if(P&&P.Filesystem&&P.Share){const r=await P.Filesystem.writeFile({path:`${name}-${stamp()}.json`,data:txt,directory:'CACHE',encoding:'utf8'});await P.Share.share({title:'D&D backup',url:r.uri,dialogTitle:'ذخیره‌ی پشتیبان'});return}}catch(e){if(/cancel/i.test(String(e)))return}
 try{await navigator.clipboard.writeText(txt);toast('📋 پشتیبان کپی شد؛ جایی نگهش دار')}catch(e){const t=$('#bk');if(t){t.value=txt;t.select();toast('متن پشتیبان توی کادر پایین ساخته شد؛ کپی کن')}}}
function pickBackup(inp){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{PB=String(r.result);render()};r.readAsText(f)}
function importText(txt,mode){let o;try{o=JSON.parse(txt)}catch(e){return toast('فایل پشتیبان خراب یا نامعتبره')}
 if(!o||!Array.isArray(o.chars))return toast('این فایل، پشتیبان بازی نیست');
 const chars=o.chars.filter(c=>c&&c.name&&c.cls&&c.st&&CLS[c.cls]&&RACES[c.race]);if(!chars.length)return toast('کاراکتری توی فایل نبود');
 if(mode==='replace'){DB.chars=chars.map(mig);if(o.set)Object.assign(DB.set,o.set)}
 else chars.forEach(c=>{const i=DB.chars.findIndex(x=>x.id===c.id);if(i<0)DB.chars.push(mig(c));else if((c.xp||0)>=(DB.chars[i].xp||0))DB.chars[i]=mig(c)});
 PB=null;save();C=null;go('backup');toast(`✅ ${chars.length} کاراکتر بازیابی شد`)}
function restoreAuto(){const t=localStorage.getItem(KEY+'_bak');if(t&&confirm('بازی به پشتیبان خودکار برگرده؟ پیشرفت جدیدتر از دست می‌ره.'))importText(JSON.stringify({chars:JSON.parse(t).chars}),'replace')}
function vBackup(){let bak=null;try{bak=JSON.parse(localStorage.getItem(KEY+'_bak'))}catch(e){}
 return `<button class="b x" onclick="PB=null;go(C?'main':'menu')">← بازگشت</button>
<div class="card"><h3>💾 ذخیره و بازیابی اکانت</h3><div class="sm mut">اطلاعات بازی فقط روی همین گوشی می‌مونه. اگه اپ رو پاک کنی یا گوشی عوض کنی از بین می‌ره؛ پس هر از گاهی پشتیبان بگیر و جایی امن (فایل‌ها، گوگل‌درایو، تلگرام...) نگه‌دار.</div></div>
<div class="card"><b>📤 ذخیره</b><button class="b big" onclick="exportFile(null,'DnD-all')">ذخیره‌ی همه‌ی کاراکترها (${DB.chars.length})</button>${DB.chars.map(c=>`<div class="row">${av(c,36)}<div class="grow">${esc(c.name)} <span class="mut sm">لول ${c.lvl}</span></div><button class="b sm" onclick="exportFile([${c.id}],'DnD-char')">ذخیره</button></div>`).join('')}</div>
<div class="card"><b>📥 بازیابی</b>${PB?`<div class="sm">فایل خونده شد. چطور بازیابی بشه؟</div><button class="b big" onclick="importText(PB,'merge')">➕ ادغام (کاراکترهای فعلی می‌مونن)</button><button class="b big red" onclick="if(confirm('همه‌ی کاراکترهای فعلی پاک و جایگزین می‌شن. مطمئنی؟'))importText(PB,'replace')">♻️ جایگزینی کامل</button><button class="b x" onclick="PB=null;render()">لغو</button>`:`<label class="b big">📁 انتخاب فایل پشتیبان<input type="file" hidden accept=".json,application/json,text/plain" onchange="pickBackup(this)"></label>`}
<div class="sm mut" style="margin-top:8px">یا متن پشتیبان رو اینجا بچسبون:</div><textarea id="bk" class="in" rows="3"></textarea><button class="b" onclick="PB=$('#bk').value;if(PB)render()">بررسی متن</button></div>
${bak&&bak.chars?`<div class="card"><b>⏪ پشتیبان خودکار</b><div class="sm mut">بازی روزی یه بار خودش نسخه‌ی قبلی رو نگه می‌داره (${bak.chars.length} کاراکتر). برای وقتی که چیزی خراب شد.</div><button class="b" onclick="restoreAuto()">بازگشت به پشتیبان خودکار</button></div>`:''}`}

// ===== پنل ادمین =====
const vALogin=()=>`<button class="b x" onclick="go('menu')">← بازگشت</button><div class="card"><h3>🛠 پنل ادمین</h3><div class="sm mut">رمز پیش‌فرض: 1234 (داخل پنل می‌تونی عوضش کنی)</div><input id="pin" type="password" class="in" placeholder="رمز"><button class="b big" onclick="aLogin()">ورود</button></div>`;
function aLogin(){if($('#pin').value!==String(DB.set.pin))return toast('رمز اشتباهه');if(!DB.chars.length)return toast('اول یه کاراکتر بساز');AD=null;C=null;view='admin';render()}
function aNum(id){return Math.max(0,Math.floor(+($('#'+id).value)||0))}
function vAdmin(){let h=`<button class="b x" onclick="C=null;go('menu')">← خروج از ادمین</button><div class="card"><h3>🛠 پنل ادمین</h3>`;
 if(!C){return h+'<div class="mut sm">کاراکتر مورد نظر رو انتخاب کن:</div>'+DB.chars.map((c,i)=>`<div class="row">${av(c,40)}<div class="grow">${esc(c.name)} <span class="mut sm">لول ${c.lvl}</span></div><button class="b sm" onclick="C=mig(DB.chars[${i}]);render()">انتخاب</button></div>`).join('')+'</div>'}
 const k=calc(C);
 h+=`<div>${av(C,40)} <b>${esc(C.name)}</b> <span class="mut sm">لول ${C.lvl} · 🪙${fmt(C.gold)} · 💠${C.stone}</span></div><button class="b sm x" onclick="C=null;render()">تغییر کاراکتر</button></div>
<div class="card"><b>🪙 منابع</b><div class="chips"><button class="chip" onclick="aG(1000)">+۱K</button><button class="chip" onclick="aG(100000)">+۱۰۰K</button><button class="chip" onclick="aG(10000000)">+۱۰M</button><button class="chip" onclick="aS(10)">+۱۰ 💠</button><button class="chip" onclick="aS(100)">+۱۰۰ 💠</button></div></div>
<div class="card"><b>⭐ لول</b><div class="chips"><button class="chip" onclick="aL(C.lvl+1)">+۱</button><button class="chip" onclick="aL(C.lvl+5)">+۵</button><button class="chip" onclick="aL(C.lvl+20)">+۲۰</button></div><div class="row"><input id="alv" type="number" class="in" placeholder="لول دلخواه"><button class="b" onclick="aL(Math.max(1,aNum('alv')))">تنظیم</button></div></div>
<div class="card"><b>🏅 رنک</b><div class="sm mut">انفرادی</div><div class="chips">${RANKS.map((r,i)=>`<button class="chip ${C.rank===i?'on':''}" onclick="C.rank=${i};C.rep=Math.max(C.rep,RANKREP[${i}]);save();render()">${r}</button>`).join('')}</div><div class="sm mut">تیمی</div><div class="chips">${RANKS.map((r,i)=>`<button class="chip ${C.trank===i?'on':''}" onclick="C.trank=${i};C.trep=Math.max(C.trep,RANKREP[${i}]);save();render()">${r}</button>`).join('')}</div></div>
<div class="card"><b>📊 ویژگی‌ها</b>${STATS.map(([s,n])=>`<div class="row"><span class="grow">${n}</span><button class="b sm" onclick="C.st['${s}']=Math.max(0,C.st['${s}']-1);save();render()">−</button><b>${C.st[s]}</b><button class="b sm" onclick="C.st['${s}']++;save();render()">+</button></div>`).join('')}<button class="b sm" onclick="C.free+=10;save();render()">+۱۰ امتیاز آزاد (${C.free})</button></div>
<div class="card"><b>🧪 حالت‌ها</b>${tg('god','جان بی‌نهایت (آسیب نمی‌خوری)')}${tg('ohk','کشتن با یک ضربه')}${tg('fm','مهارت بدون هزینه')}<button class="b" onclick="const k=calc(C);C.hp=k.hpMax;C.mp=k.mpMax;C.comps.forEach(p=>p.hp=cmax(p));save();toast('✅ پر شد');render()">❤️ پر کردن جان و منبع</button></div>
<div class="card"><b>🗼 برج</b><div class="row"><input id="atw" type="number" class="in" placeholder="طبقه (الان ${C.tower})"><button class="b" onclick="C.tower=aNum('atw');save();render()">تنظیم</button></div></div>
<div class="card"><b>🎁 افزودن آیتم</b>${chips([...SLOTS,['potion','معجون']],ADS,'setADS')}<input class="in" placeholder="جستجوی اسم..." value="${esc(ADQ)}" oninput="ADQ=this.value;adList()"><input id="adu" type="number" class="in" placeholder="سطح ارتقا (۰ تا ۱۵)" value="0"><div id="adl">${adListH()}</div></div>
<div class="card"><b>👹 احضار هیولا (تست)</b>${chips(AKEYS.map(a=>[a,AREAS[a].e]),ADM,'setADM')}${[...AREAS[ADM].mon,AREAS[ADM].boss].map((m,i)=>`<div class="row"><div style="width:46px">${art(m)}</div><div class="grow">${m.n} <span class="mut sm">لول ${m.lv}</span></div><button class="b sm" onclick="startFight(${i<4?`AREAS['${ADM}'].mon[${i}]`:`AREAS['${ADM}'].boss`},'${ADM}','mon')">مبارزه</button></div>`).join('')}</div>
<div class="card"><b>🔐 رمز و داده</b><div class="row"><input id="npin" class="in" placeholder="رمز جدید"><button class="b" onclick="if($('#npin').value){DB.set.pin=$('#npin').value;save();toast('رمز عوض شد')}">ثبت</button></div><button class="b red" onclick="if(confirm('همه‌ی کاراکترها پاک بشن؟')){DB.chars=[];save();C=null;go('menu')}">🗑 پاک کردن کل ذخیره‌ها</button></div>`;return h}
function aG(n){C.gold+=n;save();render()}function aS(n){C.stone+=n;save();render()}
function aL(n){const old=C.lvl;C.lvl=n;C.xp=n>1?thr(n-1):0;if(n>old)C.free+=2*(n-old);const k=calc(C);C.hp=k.hpMax;C.mp=k.mpMax;save();render()}
function setADS(k){ADS=k;render()}function setADM(k){ADM=k;render()}
function adListH(){const q=ADQ.trim();return Object.keys(ITEMS).filter(i=>ITEMS[i].t===ADS&&(!q||ITEMS[i].n.includes(q))).sort((a,b)=>ITEMS[a].p-ITEMS[b].p).slice(0,25).map(id=>`<div class="row it"><div class="grow" style="color:${RCOL[ITEMS[id].r]}">${ITEMS[id].e} ${ITEMS[id].n}</div><button class="b sm" onclick="aAdd('${id}')">+</button></div>`).join('')||'<div class="mut sm">چیزی پیدا نشد</div>'}
function adList(){$('#adl').innerHTML=adListH()}
function aAdd(id){C.inv.push(mk(id,Math.min(UMAX,aNum('adu'))));save();toast('✅ اضافه شد: '+ITEMS[id].n)}
render();
